-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a302
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `study_group`
--

DROP TABLE IF EXISTS `study_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `study_group` (
  `current_num` double NOT NULL,
  `max_num` double NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `group_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mascot_id` bigint(20) DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `UK9tdkhxbij1frtql0gpfdx3ura` (`mascot_id`),
  CONSTRAINT `FK723aef5o9iuhsisi8calbmvga` FOREIGN KEY (`mascot_id`) REFERENCES `mascot` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `study_group`
--

LOCK TABLES `study_group` WRITE;
/*!40000 ALTER TABLE `study_group` DISABLE KEYS */;
INSERT INTO `study_group` VALUES (5,0,'2024-07-15 01:27:30.371438',6,6,'c137f399-17bf-4a48-bcfd-f75b10b1f27b',NULL,'시연용'),(1,0,'2024-08-14 04:08:01.083340',22,22,'d7920df8-b14d-478d-8ff0-867fac8e4ace',NULL,'알고리즘 스터디'),(1,0,'2024-08-14 04:37:13.880712',23,23,'074bf923-2e0b-48bb-960e-bdd215b981bc',NULL,'귀여운 스터디'),(1,0,'2024-08-14 04:44:55.681588',24,24,'95e69383-7086-4a46-9f7b-1d329c132914',NULL,'알고팜'),(1,0,'2024-08-14 04:45:24.044952',25,25,'17b4c8de-07cc-48a5-a991-498e09425350',NULL,'알고팜'),(1,0,'2024-08-14 06:57:15.792339',28,28,'68df0d9a-c19e-494f-8c26-4da42b2d681e',NULL,'ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㄴㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㅈㄷㄷㄷㄷㄷㄷㄷㄷㄷㄷㄷ'),(1,0,'2024-08-15 09:18:28.909382',29,29,'f38b084d-944e-4673-a323-d9694ef88fac',NULL,'도그'),(1,0,'2024-08-16 00:52:21.246922',30,30,'fadaf814-6cca-4618-9f5e-cd87874faf24',NULL,'테스트');
/*!40000 ALTER TABLE `study_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 10:12:28
