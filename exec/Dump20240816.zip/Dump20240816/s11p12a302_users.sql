-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s11p12a302
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `account_non_expired` bit(1) NOT NULL,
  `account_non_locked` bit(1) NOT NULL,
  `credentials_non_expired` bit(1) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `is_email_verified` bit(1) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `oauth_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-13 08:49:04.476550','2024-08-13 08:49:04.476565',3,'ryu.taeram@gmail.com','유태람','106618999303412349778','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-14 01:26:42.994945','2024-08-14 01:26:42.994957',5,'bjy123bjy@gmail.com','박정영','105429183255661472760','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-07-15 01:27:27.205244','2024-08-14 04:47:35.434392',6,'qnsghdharo119@gmail.com','김민지','102113883788641711633','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-14 04:43:14.472114','2024-08-14 04:43:14.472127',24,'donald08190@gmail.com','최재혁','107493406084389224001','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-14 04:46:10.293857','2024-08-14 04:46:10.293868',26,'s302found@gmail.com','found 302','104826266304521013918','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-14 04:49:28.019034','2024-08-14 04:49:28.019045',27,'cbju98@gmail.com','Byung Ju Choi','103283198170377055238','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-14 06:57:05.011021','2024-08-14 06:57:05.011034',28,'megahawk88@gmail.com','이상현','110323146446838766833','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-15 09:18:18.245592','2024-08-15 09:18:18.245620',29,'donald8190@gmail.com','최재혁','104869223549054704762','GOOGLE'),(_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '','2024-08-16 00:52:15.598766','2024-08-16 00:52:15.598834',30,'motae1122@gmail.com','최지찬','110981374173941116136','GOOGLE');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 10:12:26
